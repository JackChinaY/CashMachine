﻿using System.Data;
using System.Windows.Controls;

namespace CheckProject.utils
{
    class CommonUtils
    {
        /// <summary>
        /// dataGrid转换dataTable
        /// </summary>
        public DataTable dataGridToDataTable(DataGrid dataGrid)
        {
            try
            {
                DataTable dt = null;

                if (dataGrid.ItemsSource is DataView)
                {
                    dt = (dataGrid.ItemsSource as DataView).Table;
                }
                else if (dataGrid.ItemsSource is DataTable)
                {
                    dt = dataGrid.ItemsSource as DataTable;
                }
                else if (dataGrid.ItemsSource is DataSet)
                {
                    dt = (dataGrid.ItemsSource as DataSet).Tables[0];
                }
                return dt;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }
    }
}
